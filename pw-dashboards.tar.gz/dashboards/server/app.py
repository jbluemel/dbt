"""
Purple Wave Dashboard Server
Serves HTML dashboards and provides a query API to PostgreSQL.

Usage:
  pip install fastapi uvicorn psycopg2-binary
  cd ~/dbt-learning/dbt/dashboards
  python server/app.py

Then open: http://localhost:8080/reports/alv-september.html
"""

import json
import os
from pathlib import Path
from contextlib import asynccontextmanager

import psycopg2
import psycopg2.extras
from fastapi import FastAPI, Query, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# --- Config ---
DB_CONFIG = {
    "host": os.getenv("PG_HOST", "localhost"),
    "port": int(os.getenv("PG_PORT", "5434")),
    "database": os.getenv("PG_DATABASE", "dbt_dev"),
    "user": os.getenv("PG_USER", "postgres"),
    "password": os.getenv("PG_PASSWORD", "postgres"),
}

# Only these tables can be queried (safety guardrail)
ALLOWED_TABLES = {"itemv2"}

BASE_DIR = Path(__file__).resolve().parent.parent


# --- App ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"Dashboard server starting...")
    print(f"Serving from: {BASE_DIR}")
    print(f"PostgreSQL: {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}")
    print(f"Open: http://localhost:8080")
    yield

app = FastAPI(title="PW Dashboards", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


def get_conn():
    return psycopg2.connect(**DB_CONFIG)


# --- API Routes ---

@app.get("/api/tables")
def list_tables():
    """List available tables."""
    return {"tables": sorted(ALLOWED_TABLES)}


@app.get("/api/query")
def query_table(
    table: str = Query(..., description="Table name"),
    group_by: str = Query(None, description="Comma-separated columns to group by"),
    filters: str = Query(None, description="JSON object of column:value filters"),
    metric: str = Query("Contract Price", description="Column to aggregate"),
):
    """
    Query a gold table with optional grouping and filtering.
    Returns aggregated ALV, lots, and revenue.
    """
    if table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{table}' not allowed. Available: {ALLOWED_TABLES}")

    where_clauses = []
    params = []

    if filters:
        try:
            filter_dict = json.loads(filters)
        except json.JSONDecodeError:
            raise HTTPException(400, "Invalid JSON in filters parameter")

        for col, val in filter_dict.items():
            where_clauses.append(f'"{col}" = %s')
            params.append(val)

    where_sql = ""
    if where_clauses:
        where_sql = "WHERE " + " AND ".join(where_clauses)

    if group_by:
        group_cols = [f'"{c.strip()}"' for c in group_by.split(",")]
        group_sql = ", ".join(group_cols)
        select_cols = group_sql + ","

        sql = f"""
            SELECT {select_cols}
                COUNT(*) as lots,
                ROUND(AVG("{metric}")::numeric, 2) as avg_lot_value,
                ROUND(SUM("{metric}")::numeric, 2) as total_revenue
            FROM {table}
            {where_sql}
            GROUP BY {group_sql}
            ORDER BY {group_sql}
        """
    else:
        sql = f"""
            SELECT
                COUNT(*) as lots,
                ROUND(AVG("{metric}")::numeric, 2) as avg_lot_value,
                ROUND(SUM("{metric}")::numeric, 2) as total_revenue
            FROM {table}
            {where_sql}
        """

    try:
        conn = get_conn()
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()]
        cur.close()
        conn.close()

        # Convert Decimal to float for JSON serialization
        for row in rows:
            for k, v in row.items():
                if hasattr(v, '__float__'):
                    row[k] = float(v)

        return {"data": rows, "count": len(rows)}

    except Exception as e:
        raise HTTPException(500, f"Query error: {str(e)}")


@app.get("/api/distinct")
def distinct_values(
    table: str = Query(...),
    column: str = Query(...),
    filters: str = Query(None, description="JSON object of column:value filters"),
):
    """Get distinct values for a column, useful for populating filters."""
    if table not in ALLOWED_TABLES:
        raise HTTPException(400, f"Table '{table}' not allowed.")

    where_clauses = []
    params = []

    if filters:
        try:
            filter_dict = json.loads(filters)
        except json.JSONDecodeError:
            raise HTTPException(400, "Invalid JSON in filters parameter")

        for col, val in filter_dict.items():
            where_clauses.append(f'"{col}" = %s')
            params.append(val)

    where_sql = ""
    if where_clauses:
        where_sql = "WHERE " + " AND ".join(where_clauses)

    sql = f"""
        SELECT DISTINCT "{column}"
        FROM {table}
        {where_sql}
        ORDER BY "{column}"
    """

    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute(sql, params)
        values = [r[0] for r in cur.fetchall()]
        cur.close()
        conn.close()
        return {"column": column, "values": values}

    except Exception as e:
        raise HTTPException(500, f"Query error: {str(e)}")


# --- Static File Serving ---

# Serve static assets (CSS, JS)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

# Serve report HTML files
app.mount("/reports", StaticFiles(directory=str(BASE_DIR / "reports"), html=True), name="reports")


# Root redirect
@app.get("/")
def root():
    return {"message": "PW Dashboards", "reports": "/reports/", "api": "/api/tables"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
